import java.util.Scanner;

public class DecipherTheMessage {
	public static String message(String seq, StringBuilder word)
	{
		String newWord = "";
		if(word.equals(""))
		{
			return "";
		}
		if(!seq.contains("R") && !seq.contains("D"))
		{
			return "error";
		}
		for(int i = 0; i < seq.length(); i++)
		{
			if(seq.charAt(i) == 'R')
			{
				word.reverse();
			}
			else if(seq.charAt(i) == 'D')
			{
				if(word.length() == 0)
				{
					return "error";
				}
				word.deleteCharAt(0);
			}
		}
		newWord = word.toString();
		return newWord;
	}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String seq = input.nextLine();
		StringBuilder word = new StringBuilder(input.nextLine());
		System.out.println(message(seq, word));
	}
}
