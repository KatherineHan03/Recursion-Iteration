import java.util.*;

public class ParsingBrackets {
	public static String parse(String phrase)
	{
		if(phrase.isEmpty())
		{
			return "YES";
		}
		Stack<Character> brackets = new Stack<Character>();
		for(int i = 0; i < phrase.length(); i++)
		{
			if(phrase.charAt(i) == '(' || phrase.charAt(i) == '[' || phrase.charAt(i) == '{')
			{
				brackets.push(phrase.charAt(i));
			}
			if(phrase.charAt(i) == ')' || phrase.charAt(i) == ']' || phrase.charAt(i) == '}')
			{
				if(brackets.isEmpty())
				{
					return "NO " + (i + 1);
				}
				else if(brackets.peek() == '(' && phrase.charAt(i) == ')' || brackets.peek() == ('{') && phrase.charAt(i) == '}' || brackets.peek() == ('[') && phrase.charAt(i) == ']')
				{
					brackets.pop();
				}
				else
				{
					return "NO " + (i + 1);
				}
			}
		}
		if(brackets.isEmpty())
		{
			return "YES";
		}
		else
		{
			return "NO " + (phrase.length() + 1);
		}
	}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String phrase = input.nextLine();
		System.out.println(parse(phrase));
	}
}
