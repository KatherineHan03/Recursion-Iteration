import java.util.*;
/**
 * This class continuously finds the sum of the individual digits of the user inputed number until it is a single digit.
 * It contains two methods and an instance variable: the main method, the recursive method to calculate the single digit sum, and the instance variable that sets sum to 0 
 * @author Katherine Han
 * @version 04/16/2023
 */
public class AllTheDigits {
	private static int sum = 0;
	/**
	 * Recursively finds the user input digit's sum until the sum is no greater than 9.
	 * @param StringBuilder str is the user inputed number in the type of StringBuilder 
	 * @return the final single digit sum
	 */
	public static int sumDigits(StringBuilder str)
	{
		sum = sum + Integer.parseInt(str.substring(0, 1));
		if(str.length() == 1 && sum < 10)
		{
			return sum;
		}
		else if(str.length() == 1 && sum >= 10)
		{
			str.replace(0, str.length(), Integer.toString(sum));
			sum = 0;
		}
		else
		{
			str.deleteCharAt(0);
		}
		return sumDigits(str);
	}
	/**
	 *  The main method that gets user input and prints the sumDigits method return value
	 */
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		StringBuilder str = new StringBuilder(input.next());
		System.out.println(sumDigits(str));
	}
}
