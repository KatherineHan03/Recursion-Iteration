import java.util.*;

public class WelcomeToNYU {
	public static String game(int size, int[] list, int target)
	{
		Arrays.sort(list);
		int sum = 0;
		int p = -1;
		int r = -1;
		for(int i = 0; i < size; i++)
		{
			for(int k = i + 1; k < size; k++)
			{
				sum = list[k] + list[i];
				if(sum == target && p < 0)
				{
					p = list[i];
					r = list[k];
				}
				else if(p > 0 && sum == target && Math.abs(p - r) > Math.abs(list[i] - list[k]))
				{
					p = list[i];
					r = list[k];
				}
				else if(sum >= target)
				{
					break;
				}
			}
		}
		if(p <= r)
		{
			return p + " " + r;
		}
		else 
		{
			return r + " " + p;
		}
	}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		int[] list = new int[size];
		for(int i = 0; i < size; i++)
		{
			list[i] = input.nextInt();	
		}
		int target = input.nextInt();
		System.out.println(game(size, list, target));
	}
}
