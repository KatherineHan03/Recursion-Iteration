import java.util.*;

public class CIMSPrinter {
	public static int print(int pos, int size, Queue<Integer> list)
	{
		int priority = 9;
		int min = 0;
		boolean condition = false;
		while(condition == false && list.peek() != null)
		{
			//set priority
			while(!list.contains(priority))
			{
				priority--;
			}
			//move head to tail
			int num = list.peek();
			if(list.peek() == priority && pos != 0)
			{
				min++;
				list.remove();
				size--;
				pos--;
			}
			
			else if(list.peek() == priority && pos == 0)
			{
				min++;
				return min;
			}
			else
			{
				list.remove();
				list.add(num);
				pos--;
			}
			if(pos < 0)
			{
				pos = size - 1;
			}
		}
		return min;
	}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		Queue<Integer> list = new LinkedList<>();
		int size = input.nextInt();
		int pos = input.nextInt();
		input.nextLine();
		for(int i = 0; i < size; i++)
		{
			list.add(input.nextInt());
		}
		System.out.println(print(pos, size, list));
	}
}
