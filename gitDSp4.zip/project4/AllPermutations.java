import java.util.*;
/**
 * This class finds all the binary sequences of a length 0 - n recursively.
 * It contains three methods: the main method, the recursive method to calculate the different permutations, and the method to set the String bin as a blank String 
 * @author Katherine Han
 * @version 04/16/2023
 */
public class AllPermutations
{
	/**
	 * Sets the String bin in the allPerm parameter (allPerm(int n, String bin)) to "" 
	 * @param int n is the user's input number
	 * @return the call to the allPerm(int n, String bin) with String bin as ""
	 */
	public static String allPerm(int n)
	{
		return allPerm(n, "");
	}
	/**
	 * Recursively finds all the binary sequences equal to or under the length of n
	 * @param int n is the user's input number
	 * @param String bin is the binary sequence 
	 * @return the binary sequence calculated
	 */
	public static String allPerm(int n, String bin)
	{
		if(bin.length() == n)
		{
			return bin;
		}
		String bin0 = bin + "0";
		String bin1 = bin + "1";
		bin += " " + allPerm(n, bin0);
		bin += " " + allPerm(n, bin1);
		return bin;
	}
	/**
	 *  The main method that gets user input and prints the allPerm method return value
	 */
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		System.out.println(allPerm(num));
	}
}