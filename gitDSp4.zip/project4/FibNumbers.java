import java.util.Scanner;
/**
 * This class recursively calculates the N'th number in the Fibonacci sequence
 * It contains two methods: the main method and the recursive method to calculate the N'th Fibonacci number 
 * @author Katherine Han
 * @version 04/16/2023
 */
public class FibNumbers
{
	/**
	 * Uses recursion and an array to efficiently determine the user input's number in the Fibonacci sequence 
	 * @param int n is the user's input number
	 * @param int fibNum[] is the array that sees if values were already determined previously
	 * @return the addition of a recursive call to the fibonacci method with int n - 1 and the recursive call to the fibonacci method with int n - 2
	 */
	public static int fibonacci(int n, int fibNum[])
	{
		if(n <= 2)
		{
			return 1; 
		}
		if(fibNum[n] != 0)
		{
			return fibNum[n];
		}
		else
		{
			fibNum[n] = fibonacci(n - 1, fibNum) + fibonacci(n - 2, fibNum);
		}
		return fibonacci(n - 1, fibNum) + fibonacci(n - 2, fibNum);
	}
	/**
	 * The main method that gets user input and prints the fibonacci method return value
	 */
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		int[] fibNum = new int[num + 1];
		System.out.println(fibonacci(num, fibNum));
	}
}